import logo from './logo.svg';
import './App.css';
import Myredux from './components/Myredux';
import {useSelector} from 'react-redux'
function App() {
  const mycount=useSelector(state=> state.count);
  return (
    <div className="App">
        <h2> Redux Implementation Counter ({mycount}) </h2>
        <Myredux />
    </div>
  );
}

export default App;
