import React from 'react'
import {useSelector,useDispatch} from 'react-redux';
export default function Myredux() {
    const mycount=useSelector(state=> state.count);
    const dispatch=useDispatch();
  return (
      <>
         <h2> Redux Counter</h2>
         <p> The counter is {mycount}</p>
         <button onClick={()=> dispatch({type:"INC",payload:2})}> Increment</button>
         <button onClick={()=> dispatch({type:"DEC",payload:1})}> Decrement</button>
         <button onClick={()=> dispatch({type:"RESET"})}> Reset</button>
      </>
  )
}
